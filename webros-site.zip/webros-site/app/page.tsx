import GrainOverlay from "@/components/GrainOverlay";
import ScrollProgress from "@/components/ScrollProgress";
import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import TrustStrip from "@/components/TrustStrip";
import Services from "@/components/Services";
import WorkBoard from "@/components/WorkBoard";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";

export default function Home() {
  return (
    <div className="relative" style={{ minHeight: "100vh", overflowX: "hidden" }}>
      <GrainOverlay />
      <ScrollProgress />
      <Nav />
      <Hero />
      <TrustStrip />
      <Services />
      <WorkBoard />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
