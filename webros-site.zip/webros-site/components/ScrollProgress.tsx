"use client";

import { useEffect, useRef } from "react";

export default function ScrollProgress() {
  const barRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onScroll = () => {
      const scrolled = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      const pct = height > 0 ? Math.min(scrolled / height, 1) : 0;
      if (barRef.current) barRef.current.style.transform = `scaleY(${pct})`;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className="fixed hidden lg:block"
      style={{
        right: 20,
        top: "50%",
        transform: "translateY(-50%)",
        height: 120,
        width: 2,
        background: "var(--wire)",
        zIndex: 35,
        borderRadius: 2,
      }}
      aria-hidden="true"
    >
      <div
        ref={barRef}
        style={{
          width: "100%",
          height: "100%",
          background: "var(--brass)",
          transformOrigin: "top",
          transform: "scaleY(0)",
          borderRadius: 2,
          transition: "transform 0.1s linear",
        }}
      />
    </div>
  );
}
